# Supabase full backup → local reproduction

Everything needed to archive a Supabase project and rebuild it locally.

## What "everything" actually means

A Supabase project is **five** separate stores. A database dump only covers #1.
Most "incomplete backup" pain comes from forgetting #2, #4 and #5.

| # | Store | Covered by | In this archive? |
|---|-------|-----------|------------------|
| 1 | Postgres database (all schemas + data + roles) | `backup-supabase.sh` | ✅ |
| 2 | Storage **objects** (the actual files, live in S3) | `supabase storage cp` | ⚠️ separate step |
| 3 | Storage **metadata** (`storage.buckets`/`objects` rows) | database dump | ✅ |
| 4 | Edge Functions (source + deno config) | `supabase functions download` | ⚠️ separate step |
| 5 | Edge Function **secrets** + Auth provider configs + API keys | cannot be dumped | ❌ re-enter by hand |

---

## Prerequisites (already installed on this machine)

```bash
brew install libpq                    # pg_dump / psql 18.6
brew install supabase/tap/supabase    # supabase CLI 2.120.0
# libpq is keg-only — put it on PATH:
export PATH="/opt/homebrew/opt/libpq/bin:$PATH"
```

## Get your connection string

Supabase Dashboard → **Connect** → use the **Session pooler** string:

```
postgresql://postgres.<project-ref>:<password>@aws-0-<region>.pooler.supabase.com:5432/postgres
```

Use the **Direct** string (`db.<project-ref>.supabase.co`) instead if you have IPv6 or
the IPv4 add-on. The database password lives under **Database → Settings** (you can reset it there).

Session pooler is on port **5432** — if you point `pg_dump` at port 6543 (transaction pooler)
it will fail, because that mode doesn't support the session-level operations `pg_dump` needs.

---

## 1. Dump the database

```bash
cd ~/supabase-backup
export SUPABASE_DB_URL='postgresql://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:5432/postgres'
./backup-supabase.sh
```

Produces `supabase-backup-YYYYmmdd-HHMMSS/` and a `.tar.gz` of it:

| File | What it is |
|------|-----------|
| `roles.sql` | cluster roles (created before schema on restore) |
| `schema.sql` | DDL of **every** schema — `public`, `auth`, `storage`, custom |
| `data.sql` | all table data, `COPY` format |
| `full.sql` | schema + data in one plain-SQL file |
| `database.dump` | **custom format** — the primary restore artifact |
| `manifest.txt` | server version, db size, extensions, per-table row counts |
| `SHA256SUMS` | integrity checksums |

The script refuses to proceed if `pg_dump` is older than the server, and drops the two
`storage.*` internal tables that break a restore.

> `pg_dump` can't read the *passwords* of Supabase-managed roles. `roles.sql` gets the
> roles and grants (what actually matters for RLS/ownership); reset any custom `LOGIN`
> role's password manually after restoring.

### Alternative: official CLI dump
`supabase db dump` runs `pg_dump` inside a Docker container and deliberately **excludes**
the managed `auth`/`storage` schemas — it's tuned for pushing into a fresh Supabase project,
not for a complete archive. Use it if that's your target:

```bash
supabase db dump --db-url "$SUPABASE_DB_URL" -f roles.sql  --role-only
supabase db dump --db-url "$SUPABASE_DB_URL" -f schema.sql
supabase db dump --db-url "$SUPABASE_DB_URL" -f data.sql --data-only \
  -x "storage.buckets_vectors" -x "storage.vector_indexes"
```

---

## 2. Storage objects (the actual files)

`storage` DB rows only hold *pointers*; the bytes live in S3. Pull them with the CLI
(needs `supabase login` and a linked/known project ref):

```bash
supabase login
supabase storage ls -r --project-ref <ref> ss:///          # see all buckets/paths
# per bucket, copy the whole tree down:
supabase storage cp -r --project-ref <ref> \
  ss:///my-bucket file:///Users/michomauricio/supabase-backup/storage/my-bucket
```

Schemes: `ss://` = Supabase Storage, `file://` = local filesystem (`ss:///bucket/path`).

---

## 3. Edge Functions

```bash
supabase functions list --project-ref <ref>
supabase functions download <name> --project-ref <ref>   # into supabase/functions/<name>
```

This does **not** fetch `deno.json` / import maps — copy those by hand.
Function **secrets** are never exported: read them from Dashboard → Edge Functions → Secrets
and store them yourself.

---

## Restoring locally

### Option A — plain local Postgres (truest reproduction)

`database.dump` contains every schema including `auth` and `storage` as ordinary tables,
so a single restore gives you a byte-level copy of the project's data:

```bash
createdb supabase_archive
pg_restore -d supabase_archive --no-owner --no-privileges database.dump
psql supabase_archive -c '\dt auth.*' -c '\dt storage.*'
```

If you want roles too: `psql -d supabase_archive -f roles.sql` **first**, then restore.
Comment out lines matching `OWNER TO "supabase_admin"` or `GRANT ... cli_login_postgres`
if they error — those roles don't exist outside Supabase's platform.

### Option B — self-hosted Supabase stack (Docker)

If you want a *running* Supabase local dev stack, don't restore `auth`/`storage` wholesale:
the local GoTrue and Storage services own those schemas and a foreign copy collides with them.

```bash
supabase init
supabase start
# restore only your own schemas:
pg_restore -d 'postgresql://postgres:postgres@127.0.0.1:54322/postgres' \
  --schema=public --no-owner database.dump
# then upload the storage tree back:
supabase storage cp -r --local file:///…/storage/my-bucket ss:///my-bucket
supabase functions deploy --local
```

Recreate Auth users afterwards — either via the Admin API (`service_role` key,
`POST /auth/v1/admin/users`) or by inserting the dumped `auth.users` / `auth.identities`
rows. Password hashes are bcrypt and GoTrue will accept them, but validate against your
GoTrue version before relying on it for a large user table.

Reference: <https://supabase.com/docs/guides/platform/migrating-within-supabase/backup-restore>
