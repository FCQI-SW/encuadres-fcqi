# Backup of `encuadres-fcqi-v2` — restore notes

Project ref: `ykelcalpppwbdaifljay` · Region: `us-west-1` · Postgres 17.6.1.155
Dumped with `pg_dump` 18.6 (client newer than server — correct direction).

## What is in here

| File | Contents |
|------|----------|
| `database.dump` | **Primary artifact.** Custom-format dump, `pg_restore`-able. All schemas except the exclusions below. |
| `schema.sql` | Plain-SQL DDL: tables, functions, triggers, RLS policies, indexes, sequences, types, extensions, publications. |
| `data.sql` | Data in `COPY` format (public schemas). |
| `full.sql` | Schema + data in one plain-SQL file. |
| `storage-data.sql` | `storage.buckets` (1 row) + `storage.objects` (4 rows). Applied separately — see below. |
| `storage/` | The **actual uploaded files** (4 files, byte-exact, verified against `storage.objects` metadata). |
| `roles.sql` | 18 cluster roles (Supabase platform roles + grants). Passwords are not readable by `pg_dump`. |
| `project-config/` | Auth / PostgREST / Storage / Realtime / pooler settings and project metadata, as JSON. |
| `manifest.txt` | Server version, DB size, extensions, per-table row counts (from the live DB). |
| `SHA256SUMS` | Checksums of every file. |

## Verified

Restored into a clean local Postgres and compared: **all 27 `public` tables row-for-row identical (78/78 rows)**,
`storage.objects` 4/4, `storage.buckets` 1/1, 8 public functions, 2 user triggers, 6 of 9 public RLS policies
(the other 3 need the `auth` schema — see below). Storage files match their recorded sizes exactly.

## What is NOT in here, and why

- **`auth`, `realtime`, `pgsodium`, `vault`, `graphql`, `graphql_public` schemas.** Platform-managed. They are
  recreated by Supabase itself and are deliberately excluded, matching Supabase's own guidance. In this project
  `auth` held **zero rows** (no users), so nothing was lost.
- **13 auth/storage tables `postgres` is not the owner of and cannot grant on** (e.g. `auth.oauth_clients`,
  `auth.scim_users`, `storage.migrations`). Also zero rows. Read the platform's copies if ever needed.
- **Edge Function secrets, API keys (anon/service_role) and the JWT secret.** Not obtainable from a dump.
  Get them from the Dashboard if you need byte-identical tokens.
- **Edge Functions:** none exist on this project (`functions` list is empty).

## Restoring

### Into a plain local Postgres (truest reproduction)
```bash
createdb encuadres_restore
psql -d encuadres_restore -f roles.sql                    # optional: roles first
pg_restore -d encuadres_restore --no-owner --no-privileges database.dump
psql -d encuadres_restore -f storage-data.sql             # storage metadata
```
Expected errors, all harmless: Supabase-only extensions (`pg_graphql`, `pgsodium`, `supabase_vault`, `pgjwt`),
platform roles (`supabase_admin`, `cli_login_postgres`), and 3 RLS policies that reference `auth.users`.
Comment out lines matching `OWNER TO "supabase_admin"` if they block you.

### Into a self-hosted Supabase stack (Docker)
```bash
supabase init && supabase start
pg_restore -d 'postgresql://postgres:postgres@127.0.0.1:54322/postgres' \
  --schema=public --no-owner database.dump
psql -d 'postgresql://postgres:postgres@127.0.0.1:54322/postgres' -f storage-data.sql
# then the files:
supabase --experimental storage cp <local-file> ss:///evidencias-encuadre/<path>   # per file; -r remote→local is unsupported
```
On the Supabase stack `auth` exists, so all 9 policies apply cleanly.

## Extensions required

`pgcrypto`, `pg_graphql`, `pg_stat_statements`, `pgjwt`, `pgsodium`, `supabase_vault`, `uuid-ossp`.

## Note on `storage-data.sql`

`storage.buckets` and `storage.objects` have row-level security enabled, so `pg_dump` cannot read their data
without `BYPASSRLS`. `--exclude-table-data` was used for them and the rows were exported through the Supabase
Management API instead, where `postgres` does bypass RLS. Generated columns (e.g. `path_tokens`) are omitted
so Postgres recomputes them on restore — verified working.

## Security housekeeping

The dump and this archive were produced using a **temporary database role** (`bkp_tmp_hermes`) created through
the Management API, because the supplied database password was rejected. That role has been **dropped** and all
its grants and helper RLS policies revoked — the database is back to its original state.

Still worth doing, because they were shared in plain text during this session:
1. **Rotate the Supabase personal access token** — Dashboard → Account → Access Tokens.
2. **Reset the database password** — Dashboard → Database → Settings.

Neither is in this archive.
