--
-- PostgreSQL database dump
--

\restrict g4h9Sd5LRp0lSd7JPAliL1nXmN38BVIWk6j0nebFVdByFsfMmAzL5t83amw3Lgx

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = on;

--
-- Data for Name: anuncios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.anuncios (id, titulo, mensaje, destinatarios, enviado_at, estado, metodo, created_at) FROM stdin;
2e63b2de-6799-4031-ab68-d47e18c4bf5e	prueba	esto es una prueba	{alumno}	2025-08-14 21:13:22.895+00	enviado	correo	2025-08-15 01:16:20.150852+00
5fc577b8-98f4-46f2-8d9b-59496244d9a7	testewt	adawdasd	{profesor,personal,alumno}	2025-09-05 00:12:00.53+00	enviado	correo	2025-09-05 00:11:57.075126+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, nombre) FROM stdin;
aa8c221f-f599-4868-aff4-9c87c86c88b3	admin
bc3ab654-5fc8-401a-a6e2-97903b45cc93	profesor
9387fe64-2179-4105-9661-a2e7866a7451	alumno
e4585799-f954-4ecb-9c5f-4b859cec0ee4	capturista
6c32d563-0f56-4e2d-a93b-845a7a2aca54	lector
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, nombre, "contraseña", rol_id, correo, debe_cambiar_password, password_expira_at) FROM stdin;
3ccb8042-e61a-4bef-8982-c52755773955	user capturista	$2a$06$0gz5bIF8m.ukl4wF0peFg.mNloveBNs/6je/.xqO.eahJ1d/3PPL2	e4585799-f954-4ecb-9c5f-4b859cec0ee4	capturista@gmail.com	f	\N
8f9a9302-2f1b-4923-a797-4b21b5ab7703	user alumno	$2a$06$wM1dlO4es4aLcdvsLsM9remnvKnVUY2csAqKjGJ8DeCTo0oPFW5HS	9387fe64-2179-4105-9661-a2e7866a7451	alumno@gmail.com	f	\N
cb91dfa4-5e4d-4860-92dc-917b5c82bd02	user lector	$2a$06$w8j/gCUBoQoyPVLlvNAsU.Q/y2qKD/ALnI9V89deTFr3e/pjeJqe2	6c32d563-0f56-4e2d-a93b-845a7a2aca54	lector@gmail.com	f	\N
34666b72-6cea-40ad-b2b2-a0e8d7166220	user admin	$2a$06$/5LJqefotFZc60vz3uydDu8iWB9OtIflD6cGJ.cg53LG2GKAejtqe	aa8c221f-f599-4868-aff4-9c87c86c88b3	admin@gmail.com	f	\N
555d5217-49f4-485f-a727-03fa1b80bc83	user profesor	$2a$06$tXRM1nzOXygWWkJ3g71nx.Md.PwUx28vfRnobp9VyFOsUi4SKGlP.	bc3ab654-5fc8-401a-a6e2-97903b45cc93	profe@gmail.com	f	\N
6939ee2d-a0c5-4837-8bba-7ddba7a2a239	user profesor2	$2a$06$tXRM1nzOXygWWkJ3g71nx.Md.PwUx28vfRnobp9VyFOsUi4SKGlP.	bc3ab654-5fc8-401a-a6e2-97903b45cc93	profe2@gmail.com	f	\N
d3ba5bfd-cf33-4e48-9786-c638b623d0f0	alumno2	$2b$12$s5GiqfurBK9EEdE63uLcduqDpKW6XCrUZFhT2fdkLBsxLWJM5pvS6	9387fe64-2179-4105-9661-a2e7866a7451	alumno2@uabc.edu.mx	f	\N
\.


--
-- Data for Name: auditoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auditoria (id, accion, usuario_id, fecha) FROM stdin;
\.


--
-- Data for Name: licenciaturas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.licenciaturas (id, nombre, activa, created_at) FROM stdin;
125cb2ac-da1d-4c7f-bc75-df52816d32fc	Tronco Común (Área de Ciencias Químicas)	t	2026-07-23 00:57:32.410543+00
338ed77c-3b39-42d4-9dd1-b95d8c054581	Ing. en Software y Tecnologías Emergentes	t	2026-07-23 00:57:32.410543+00
3a94e593-3f1e-41d3-b9c7-bf49a3dd0525	Ing. en Computación	t	2026-07-23 00:57:32.410543+00
\.


--
-- Data for Name: materias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.materias (id, clave, nombre_materia, licenciatura, categoria, requisito, created_at, estado, licenciatura_id, periodo, plan_estudios, archivada) FROM stdin;
06a45149-7abb-4222-bd87-d6f742f27325	12A30T	Civica y etica	Tronco Común (Área de Ciencias Químicas)	Basica	obligatoria	2025-04-04 19:47:05.243554+00	Activa	125cb2ac-da1d-4c7f-bc75-df52816d32fc	\N	\N	f
58f714e7-24ba-4a4d-8df4-1f499684a467	MAT202s	Álgebra Lineal	Ing. en Computación	Disciplinaria	optativa	2025-04-15 22:58:56.625147+00	Activa	3a94e593-3f1e-41d3-b9c7-bf49a3dd0525	\N	\N	f
e17e7595-5169-42b6-a142-4ca0d712b17f	123A30T	RHH	Ing. en Software y Tecnologías Emergentes	Disciplinaria	obligatoria	2025-04-04 19:36:54.869426+00	Activa	338ed77c-3b39-42d4-9dd1-b95d8c054581	\N	\N	f
\.


--
-- Data for Name: checkins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkins (id, usuario_id, materia_id, fecha, tipo, estado, coincidencia) FROM stdin;
\.


--
-- Data for Name: configuracion_fechas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.configuracion_fechas (id, fecha_inicio, fecha_fin, hora_inicio, hora_fin, activo, created_at, nombre, habilita_encuadre, habilita_firma, habilita_avances, habilita_pua) FROM stdin;
\.


--
-- Data for Name: configuraciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.configuraciones (id, horario_inicio, horario_fin, mantenimiento_inicio, mantenimiento_fin) FROM stdin;
\.


--
-- Data for Name: programas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.programas (id, materia_id, unidades, estado_programa, creado_por, publicado_at, proposito, competencia, evidencias, periodo, unidad_academica, programa_educativo, plan_estudios, hc, hl, ht, hpc, hcl, he, cr, etapa_formacion, caracter_ua, requisitos, metodo_encuadre, metodo_estrategia_docente, metodo_estrategia_alumno, referencias_basicas, referencias_complementarias, perfil_docente, ultimo_editor_id, ultima_edicion, activo, archivado, archivada_at, archivada_por) FROM stdin;
5153bdb7-a133-4ff2-bb4c-af1bf422a74c	06a45149-7abb-4222-bd87-d6f742f27325	2	borrador	\N	2025-06-27 23:58:17+00	Proposito de la materia CYE	Competencia de la materia CYE	Evidencias de la materia CYE	2025-2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	\N	\N
05018378-3f66-482f-a4fe-554cbb06b9d9	e17e7595-5169-42b6-a142-4ca0d712b17f	4	borrador	\N	2025-06-27 23:59:40+00	Proposito de la Materia RHH	Competencia de la Materia RHH	Evidencias de la Materia RHH	2025-2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	\N	\N
fece7a7b-8499-4a05-8e12-b72013287b8f	58f714e7-24ba-4a4d-8df4-1f499684a467	2	borrador	\N	2025-06-27 23:59:07+00	Proposito de la Materia Algebra Lineal	Competencia de la Materia Algebra Lineal	Evidencias de la Materia Algebra Lineal	2025-2	aaaaaa	aaaaaaaaaaa	2019-2	4	3	3	3	2	2	2	Disciplinaria	Optativa	ee	ggg	ssssssss	ttttttttt	ttttt	ttttttttt	yyyyyyyyy	3ccb8042-e61a-4bef-8982-c52755773955	2026-07-23 22:02:28.522+00	t	f	\N	\N
\.


--
-- Data for Name: encuadres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encuadres (id, programa_id, estado_encuadre, creado_por, publicado_at, usuario_id, grupo, periodo, descripcion_evaluacion, derecho_ordinario, derecho_extraordinario, descripcion_producto, bibliografia_basica, normas_conducta, profesor_puede_modificar_criterios, ultimo_editor_id, ultima_edicion, seccion) FROM stdin;
91d8f914-5ce3-4ff3-b5bd-394e76fb844d	fece7a7b-8499-4a05-8e12-b72013287b8f	borrador	\N	\N	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	2025-2	ggggggg	ff	f	hghhhhggg	ggggggg	ffffffffff	t	3ccb8042-e61a-4bef-8982-c52755773955	2026-07-23 01:39:40.389+00	\N
1accc513-3f5f-4cfd-86d8-1b4d05ada439	05018378-3f66-482f-a4fe-554cbb06b9d9	publicada	\N	2025-06-28 03:12:05+00	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	2025-2	xc	vdcvvcvc	cvvvvvv	ccccccc	cccccc	ccccccc	t	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	2026-07-24 23:07:05.905+00	\N
fee8efda-0756-40f5-a803-ab974523cff0	5153bdb7-a133-4ff2-bb4c-af1bf422a74c	borrador	\N	2025-06-28 03:10:02+00	555d5217-49f4-485f-a727-03fa1b80bc83	381	2025-2	sdsssss	ddddd	ddddd	dddddd	ggggggg	dddddddddddd	t	3ccb8042-e61a-4bef-8982-c52755773955	2026-08-06 03:37:42.517+00	\N
\.


--
-- Data for Name: criterios_acreditacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.criterios_acreditacion (id, criterio, encuadre_id) FROM stdin;
1	Criterio #1	fee8efda-0756-40f5-a803-ab974523cff0
\.


--
-- Data for Name: criterios_evaluacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.criterios_evaluacion (id, criterio, valor, encuadre_id, descripcion) FROM stdin;
2	fff	20	91d8f914-5ce3-4ff3-b5bd-394e76fb844d	
3	fff	40	91d8f914-5ce3-4ff3-b5bd-394e76fb844d	
4	fffff	40	91d8f914-5ce3-4ff3-b5bd-394e76fb844d	
5	ccc	100	1accc513-3f5f-4cfd-86d8-1b4d05ada439	
6	Examen	100	fee8efda-0756-40f5-a803-ab974523cff0	2 examenes durante el curso
\.


--
-- Data for Name: email_outbox; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_outbox (id, ad_id, user_id, email, subject, body, status, last_error, created_at, sent_at) FROM stdin;
\.


--
-- Data for Name: encuadre_alumnos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encuadre_alumnos (id, encuadre_id, alumno_id, estado, invitado_at, correo_enviado_at, clave_expira_at, ultimo_acceso, reenvios, invitado_por) FROM stdin;
e68ed31b-3eca-406b-8802-d9a1b9f8f22c	91d8f914-5ce3-4ff3-b5bd-394e76fb844d	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	pendiente	2026-08-05 18:35:23.129988+00	\N	2026-08-12 18:35:22.907+00	\N	0	6939ee2d-a0c5-4837-8bba-7ddba7a2a239
\.


--
-- Data for Name: encuadre_checkin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encuadre_checkin (id, encuadre_id, usuario_id, aceptado, justificacion) FROM stdin;
\.


--
-- Data for Name: encuadre_evidencias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encuadre_evidencias (id, encuadre_id, profesor_id, foto_url, fecha_presentacion, fecha_subida) FROM stdin;
0aecfec3-94c1-4018-a081-9b3a31b28e7e	1accc513-3f5f-4cfd-86d8-1b4d05ada439	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	https://ykelcalpppwbdaifljay.supabase.co/storage/v1/object/public/evidencias-encuadre/1accc513-3f5f-4cfd-86d8-1b4d05ada439/1784934934998.png	2026-07-24	2026-07-24 23:15:36.89228+00
\.


--
-- Data for Name: encuadre_firmas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encuadre_firmas (id, encuadre_id, alumno_id, firmado_at, nombre_firma) FROM stdin;
888cdf91-4ade-40f8-bca8-e8a76887d82d	91d8f914-5ce3-4ff3-b5bd-394e76fb844d	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	2026-08-05 19:09:58.239276+00	Luis Perez
\.


--
-- Data for Name: notificaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notificaciones (id, titulo, mensaje, tipo, admin_id, fecha_creacion, fecha_expiracion, activa) FROM stdin;
25ca82e9-46c7-4ff4-b920-32ab06b30a68	testewt	adawdasd	info	\N	2025-09-05 00:11:57.075126+00	\N	t
\.


--
-- Data for Name: notificaciones_usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notificaciones_usuarios (id, usuario_id, notificacion_id, leida, fecha_lectura, fecha_creacion) FROM stdin;
b2c69919-eddd-490d-a935-ce3820bf05f3	3ccb8042-e61a-4bef-8982-c52755773955	25ca82e9-46c7-4ff4-b920-32ab06b30a68	f	\N	2025-09-05 00:11:57.075126+00
c78d762b-4230-4d4a-9a81-374705aa9b26	8f9a9302-2f1b-4923-a797-4b21b5ab7703	25ca82e9-46c7-4ff4-b920-32ab06b30a68	f	\N	2025-09-05 00:11:57.075126+00
7c8b9eb2-024d-4494-a610-a0dd08d239b6	cb91dfa4-5e4d-4860-92dc-917b5c82bd02	25ca82e9-46c7-4ff4-b920-32ab06b30a68	f	\N	2025-09-05 00:11:57.075126+00
f8c0829d-4bd6-4276-8797-dec2ce8d214b	555d5217-49f4-485f-a727-03fa1b80bc83	25ca82e9-46c7-4ff4-b920-32ab06b30a68	f	\N	2025-09-05 00:11:57.075126+00
416d07df-afcd-40a2-b90b-454278605f84	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	25ca82e9-46c7-4ff4-b920-32ab06b30a68	f	\N	2025-09-05 00:11:57.075126+00
f418136d-3f12-4387-92a6-e6d84e4491d4	34666b72-6cea-40ad-b2b2-a0e8d7166220	25ca82e9-46c7-4ff4-b920-32ab06b30a68	t	2025-09-05 00:53:27.721+00	2025-09-05 00:11:57.075126+00
\.


--
-- Data for Name: permisos_operacion_encuadre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permisos_operacion_encuadre (id, usuario_id, encuadre_id, rol_objetivo, motivo, solo_lectura, puede_editar_encuadre, puede_gestionar_alumnos, puede_firmar, puede_registrar_avances, activo, acceso_desde, acceso_hasta, created_at, creado_por, incluye_alumnos, programa_id, puede_editar_pua) FROM stdin;
\.


--
-- Data for Name: unidades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.unidades (id, programa_id, numero, titulo, competencia, duracion, nombre, contenido, semana_inicio, semana_fin) FROM stdin;
1	fece7a7b-8499-4a05-8e12-b72013287b8f	1	\N	dddddddd	3	fffffff	1.1 gggggg\n1.2 fffffffff\n    1.2.1 gdsssss\n1.3 ffxxxxxxx\n1.4 xvvvvvvvvvvvv\n	2	3
2	fece7a7b-8499-4a05-8e12-b72013287b8f	2	\N	ccccccccccxxxxxx	2	dddddddggggggg	2.1 fffffffff\n    2.1.1 hhhhhhhhhhhh\n2.2 hhhhhhhhhhhhhxxxxxx\n2.3 aAAAAAAAAA\n    2.3.1 SSSSSSSSSS\n	4	5
\.


--
-- Data for Name: temas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temas (id, unidad_id, numero, nombre) FROM stdin;
1	1	1.1	gggggg
2	1	1.2	fffffffff
3	1	1.2.1	gdsssss
4	1	1.3	ffxxxxxxx
5	1	1.4	xvvvvvvvvvvvv
6	2	2.1	fffffffff
7	2	2.1.1	hhhhhhhhhhhh
8	2	2.2	hhhhhhhhhhhhhxxxxxx
9	2	2.3	aAAAAAAAAA
10	2	2.3.1	SSSSSSSSSS
\.


--
-- Data for Name: plan_temas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_temas (id, tema_id, semana, encuadre_id) FROM stdin;
\.


--
-- Data for Name: practicas_laboratorio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.practicas_laboratorio (id, unidad_id, numero, nombre, duracion, programa_id, unidad, competencia, descripcion, material_apoyo) FROM stdin;
1	\N	1	\N	2	fece7a7b-8499-4a05-8e12-b72013287b8f	1	fgfgfgfgfgfgfgfg	ddddddd	sassss
2	\N	1	\N	4	fece7a7b-8499-4a05-8e12-b72013287b8f	2	ffffffffff	xxxxxxxxxxx	ggggggggggg
\.


--
-- Data for Name: practicas_taller; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.practicas_taller (id, unidad_id, numero, nombre, duracion, programa_id, unidad, competencia, descripcion, material_apoyo) FROM stdin;
1	\N	1	\N	2	fece7a7b-8499-4a05-8e12-b72013287b8f	1	cccccccnb	ddddddddddsssss	fgfgfgfgfgfgfgff
2	\N	1	\N	3	fece7a7b-8499-4a05-8e12-b72013287b8f	2	ggggggg	fdfdfdfdfdfdfdfdfdfd	ggggg
\.


--
-- Data for Name: temas_checkin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temas_checkin (id, tema_id, usuario_id, grupo, tema_visto, justificacion, fecha_checkin, encuadre_id) FROM stdin;
1	1	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:12.224	\N
2	2	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:12.414	\N
3	3	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:12.575	\N
4	4	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:12.734	\N
5	5	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:12.898	\N
6	6	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:13.057	\N
7	7	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:13.207	\N
8	8	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:13.359	\N
9	9	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	t		2026-08-05 19:00:13.524	\N
10	10	6939ee2d-a0c5-4837-8bba-7ddba7a2a239	381	f	no se alcanzó a ver	2026-08-05 19:00:13.698	\N
11	1	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:34.62123	\N
12	2	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:34.836169	\N
13	3	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:34.972258	\N
14	4	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:35.170575	\N
15	5	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:35.377382	\N
16	6	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:35.514472	\N
17	7	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:35.651988	\N
18	8	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:35.79833	\N
19	9	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	t		2026-08-06 03:07:36.003651	\N
20	10	d3ba5bfd-cf33-4e48-9786-c638b623d0f0	381	f		2026-08-06 03:07:36.207251	\N
\.


--
-- Name: criterios_acreditacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.criterios_acreditacion_id_seq', 1, true);


--
-- Name: criterios_evaluacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.criterios_evaluacion_id_seq', 6, true);


--
-- Name: encuadre_checkin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.encuadre_checkin_id_seq', 1, false);


--
-- Name: plan_temas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_temas_id_seq', 1, false);


--
-- Name: practicas_laboratorio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.practicas_laboratorio_id_seq', 2, true);


--
-- Name: practicas_taller_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.practicas_taller_id_seq', 2, true);


--
-- Name: temas_checkin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.temas_checkin_id_seq', 20, true);


--
-- Name: temas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.temas_id_seq', 10, true);


--
-- Name: unidades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.unidades_id_seq', 2, true);


--
-- PostgreSQL database dump complete
--

\unrestrict g4h9Sd5LRp0lSd7JPAliL1nXmN38BVIWk6j0nebFVdByFsfMmAzL5t83amw3Lgx

