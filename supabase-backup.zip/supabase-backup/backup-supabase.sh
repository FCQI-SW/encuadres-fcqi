#!/usr/bin/env bash
#
# backup-supabase.sh — complete, self-contained archive of a Supabase project
#
# Captures, from the live project:
#   roles.sql       cluster roles (ownership/grants fidelity)
#   schema.sql      full DDL of EVERY schema (public, auth, storage, custom)
#   data.sql        all table data in COPY format
#   full.sql        everything in one plain-SQL file
#   database.dump   single custom-format dump (pg_restore-able, most faithful)
#   manifest.txt    server version, db size, per-table row counts
#   SHA256SUMS      integrity checksums
#   <name>.tar.gz   the whole lot, archived
#
# Requires only libpq (pg_dump/psql). No Docker needed.
#
# Usage:
#   export SUPABASE_DB_URL='postgresql://postgres.<ref>:<password>@<host>:5432/postgres'
#   ./backup-supabase.sh [output-dir]
#
set -euo pipefail

# ---- locate pg tools (Homebrew libpq is keg-only, not on PATH by default) ----
if ! command -v pg_dump >/dev/null 2>&1; then
  for p in "$(brew --prefix libpq 2>/dev/null)/bin" /opt/homebrew/opt/libpq/bin /usr/local/opt/libpq/bin; do
    if [ -x "$p/pg_dump" ]; then export PATH="$p:$PATH"; break; fi
  done
fi
command -v pg_dump >/dev/null 2>&1 || { echo "ERROR: pg_dump not found. Run: brew install libpq" >&2; exit 1; }

DB_URL="${SUPABASE_DB_URL:?ERROR: set SUPABASE_DB_URL to your Postgres connection string}"
OUT="${1:-supabase-backup-$(date +%Y%m%d-%H%M%S)}"

# Optional scoping (comma- or space-separated):
#   DUMP_SCHEMAS="public extensions"   -> dump only these schemas
#   DUMP_EXCLUDES="auth.oauth_clients" -> skip specific schema.table objects
SCHEMA_ARGS=()
if [ -n "${DUMP_SCHEMAS:-}" ]; then
  for s in ${DUMP_SCHEMAS//,/ }; do SCHEMA_ARGS+=(--schema="$s"); done
fi
EXCLUDE_ARGS=()
if [ -n "${DUMP_EXCLUDES:-}" ]; then
  for t in ${DUMP_EXCLUDES//,/ }; do EXCLUDE_ARGS+=(--exclude-table="$t"); done
fi
EXCLUDE_SCHEMA_ARGS=()
if [ -n "${DUMP_EXCLUDE_SCHEMAS:-}" ]; then
  for s in ${DUMP_EXCLUDE_SCHEMAS//,/ }; do EXCLUDE_SCHEMA_ARGS+=(--exclude-schema="$s"); done
fi
# When the connecting role lacks BYPASSRLS (e.g. a temporary role through the
# Supabase pooler), pg_dump's default row_security=off makes RLS-enabled tables
# error out. This makes pg_dump instead apply the reader's RLS policies.
EXCLUDE_DATA_ARGS=()
if [ -n "${DUMP_EXCLUDE_DATA:-}" ]; then
  for t in ${DUMP_EXCLUDE_DATA//,/ }; do EXCLUDE_DATA_ARGS+=(--exclude-table-data="$t"); done
fi
RS_ARGS=()
if [ -n "${DUMP_ENABLE_ROW_SECURITY:-}" ]; then RS_ARGS+=(--enable-row-security); fi

mkdir -p "$OUT"
# resolve to absolute so a relative OR absolute output path tars correctly
OUT_ABS="$(cd "$OUT" && pwd)"
OUT_NAME="$(basename "$OUT_ABS")"
OUT_PARENT="$(dirname "$OUT_ABS")"
cd "$OUT_ABS"

echo "==> $(pg_dump --version)"
# never print the password
echo "==> target: $(printf '%s' "$DB_URL" | sed -E 's#(://[^:/@]*):[^@]*@#\1:***@#')"
echo "==> output: $(pwd)"
echo

# ---- 0. connectivity + server info ----
echo "==> [0/6] connecting"
psql "$DB_URL" -Atc "select version();" >/dev/null
SERVER_VERSION="$(psql "$DB_URL" -Atc "show server_version;")"
echo "    server version: $SERVER_VERSION"

# pg_dump must be >= server major version. Warn if not.
PGDUMP_MAJOR="$(pg_dump --version | grep -oE '[0-9]+' | head -1)"
SRV_MAJOR="${SERVER_VERSION%%.*}"
if [ "$PGDUMP_MAJOR" -lt "$SRV_MAJOR" ]; then
  echo "    WARNING: pg_dump $PGDUMP_MAJOR < server $SRV_MAJOR — dump may fail. brew upgrade libpq" >&2
fi
echo

# ---- 1. roles (cluster level) ----
echo "==> [1/6] roles -> roles.sql"
if ! pg_dumpall --roles-only --no-role-passwords -d "$DB_URL" > roles.sql 2>roles.err; then
  echo "    --no-role-passwords failed; retrying WITH hashed passwords" >&2
  pg_dumpall --roles-only -d "$DB_URL" > roles.sql
fi
rm -f roles.err
echo "    $(grep -c '^CREATE ROLE\|^CREATE USER' roles.sql || true) roles"

# ---- 2. full schema, every schema ----
echo "==> [2/6] schema -> schema.sql"
pg_dump "$DB_URL" --schema-only ${SCHEMA_ARGS[@]+"${SCHEMA_ARGS[@]}"} ${EXCLUDE_ARGS[@]+"${EXCLUDE_ARGS[@]}"} ${EXCLUDE_SCHEMA_ARGS[@]+"${EXCLUDE_SCHEMA_ARGS[@]}"} -f schema.sql

# ---- 3. all data (COPY format) ----
echo "==> [3/6] data -> data.sql"
# storage.buckets_vectors / vector_indexes / migrations are managed internals that
# either choke a restore or are unreadable to a non-platform role
pg_dump "$DB_URL" --data-only \
  --exclude-table='storage.buckets_vectors' \
  --exclude-table='storage.vector_indexes' \
  --exclude-table='storage.migrations' \
  ${SCHEMA_ARGS[@]+"${SCHEMA_ARGS[@]}"} ${EXCLUDE_ARGS[@]+"${EXCLUDE_ARGS[@]}"} ${EXCLUDE_SCHEMA_ARGS[@]+"${EXCLUDE_SCHEMA_ARGS[@]}"} ${RS_ARGS[@]+"${RS_ARGS[@]}"} ${EXCLUDE_DATA_ARGS[@]+"${EXCLUDE_DATA_ARGS[@]}"} \
  -f data.sql

# ---- 4. one complete custom-format dump ----
echo "==> [4/6] full dump -> database.dump (custom format)"
pg_dump "$DB_URL" -Fc ${SCHEMA_ARGS[@]+"${SCHEMA_ARGS[@]}"} ${EXCLUDE_ARGS[@]+"${EXCLUDE_ARGS[@]}"} ${EXCLUDE_SCHEMA_ARGS[@]+"${EXCLUDE_SCHEMA_ARGS[@]}"} ${RS_ARGS[@]+"${RS_ARGS[@]}"} ${EXCLUDE_DATA_ARGS[@]+"${EXCLUDE_DATA_ARGS[@]}"} -f database.dump
echo "    -> full.sql (plain SQL, greppable)"
pg_dump "$DB_URL" ${SCHEMA_ARGS[@]+"${SCHEMA_ARGS[@]}"} ${EXCLUDE_ARGS[@]+"${EXCLUDE_ARGS[@]}"} ${EXCLUDE_SCHEMA_ARGS[@]+"${EXCLUDE_SCHEMA_ARGS[@]}"} ${RS_ARGS[@]+"${RS_ARGS[@]}"} ${EXCLUDE_DATA_ARGS[@]+"${EXCLUDE_DATA_ARGS[@]}"} -f full.sql

# ---- 5. manifest with row counts ----
echo "==> [5/6] manifest"
{
  echo "# Supabase backup manifest"
  echo "created_utc : $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "server      : $(psql "$DB_URL" -Atc 'select version();')"
  echo "database    : $(psql "$DB_URL" -Atc 'select current_database();')"
  echo "db_size     : $(psql "$DB_URL" -Atc "select pg_size_pretty(pg_database_size(current_database()));")"
  echo "pg_dump     : $(pg_dump --version)"
  echo
  echo "## installed extensions"
  psql "$DB_URL" -Atc "select extname||' '||extversion from pg_extension order by 1;"
  echo
  echo "## base tables and row counts (schema|table|rows)"
  psql "$DB_URL" -At -F'|' -c "
    select table_schema, table_name,
           (xpath('/row/cnt/text()',
              query_to_xml(format('select count(*) as cnt from %I.%I', table_schema, table_name),
              false, true, '')))[1]::text::int as rows
    from information_schema.tables
    where table_type = 'BASE TABLE'
      and table_schema not in ('pg_catalog','information_schema')
    order by table_schema, table_name;"
} > manifest.txt

# ---- 6. checksums ----
echo "==> [6/6] checksums"
shasum -a 256 roles.sql schema.sql data.sql full.sql database.dump manifest.txt > SHA256SUMS

cd "$OUT_PARENT"
tar czf "${OUT_NAME}.tar.gz" "$OUT_NAME"
echo
echo "==> DONE"
echo "    archive: ${OUT_ABS}.tar.gz  ($(du -h "${OUT_ABS}.tar.gz" | cut -f1))"
echo "    raw dir: ${OUT_ABS}"
echo
echo "    NOTE: Storage objects and Edge functions are NOT in this archive."
echo "          See README.md -> 'Storage objects' and 'Edge functions'."
