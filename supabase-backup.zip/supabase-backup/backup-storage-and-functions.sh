#!/usr/bin/env bash
#
# backup-storage-and-functions.sh — the two Supabase stores a SQL dump cannot capture
#
#   1. Storage OBJECTS  — the uploaded files themselves (live in S3, not in Postgres)
#   2. Edge Functions   — function source code
#
# Requires: supabase CLI and an authenticated session (`supabase login`).
# Schema notes: `ss://` = Supabase Storage, `file://` = local filesystem.
#
# Usage:
#   ./backup-storage-and-functions.sh <project-ref> [output-dir]
#
set -euo pipefail

REF="${1:?ERROR: pass your project ref as arg 1 (Dashboard URL: /project/<ref>/...)}"
OUT="${2:-supabase-extras-$REF-$(date +%Y%m%d-%H%M%S)}"

command -v supabase >/dev/null 2>&1 || { echo "ERROR: supabase CLI not found" >&2; exit 1; }

mkdir -p "$OUT"
OUT_ABS="$(cd "$OUT" && pwd)"
mkdir -p "$OUT_ABS/storage" "$OUT_ABS/functions"

echo "==> project: $REF"
echo "==> output : $OUT_ABS"
echo

# ---- auth check ----
if ! supabase projects list >/dev/null 2>&1; then
  echo "ERROR: not logged in. Run: supabase login" >&2
  exit 1
fi
echo "==> authenticated OK"
echo

# ---- 1. Storage objects ----
echo "==> [1/2] Storage objects"
echo "    buckets on the project:"
supabase storage ls --project-ref "$REF" "ss:///" 2>/dev/null | sed 's/^/      /' || {
  echo "    (could not list root — inspect manually with: supabase storage ls -r --project-ref $REF ss:///)"
}

# Enumerate top-level buckets, then copy each whole tree down.
BUCKETS="$(supabase storage ls --project-ref "$REF" "ss:///" 2>/dev/null \
  | sed -E 's#^ss:///##; s#/\s*$##' \
  | awk 'NF' || true)"

if [ -z "$BUCKETS" ]; then
  echo "    WARNING: no buckets parsed. List them yourself and copy per bucket:" >&2
  echo "      supabase storage cp -r --project-ref $REF ss:///BUCKET file://$OUT_ABS/storage/BUCKET" >&2
else
  for b in $BUCKETS; do
    echo "    -> $b"
    supabase storage cp -r --project-ref "$REF" \
      "ss:///$b" "file://$OUT_ABS/storage/$b" || echo "       FAILED on bucket '$b'" >&2
  done
fi
echo "    storage bytes: $(du -sh "$OUT_ABS/storage" 2>/dev/null | cut -f1)"
echo

# ---- 2. Edge Functions ----
echo "==> [2/2] Edge Functions"
FUNCS="$(supabase functions list --project-ref "$REF" 2>/dev/null \
  | awk 'NR>1 && $1 !~ /^(ID|NAME|---)/ {print $1}' || true)"

if [ -z "$FUNCS" ]; then
  echo "    no functions found (or list failed) — check the dashboard"
else
  for f in $FUNCS; do
    echo "    -> $f"
    ( cd "$OUT_ABS/functions" && supabase functions download "$f" --project-ref "$REF" ) \
      || echo "       FAILED on function '$f'" >&2
  done
fi
echo

# ---- manifest + archive ----
{
  echo "# Supabase extras manifest"
  echo "created_utc : $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "project_ref : $REF"
  echo
  echo "## buckets"
  echo "$BUCKETS"
  echo
  echo "## edge functions"
  echo "$FUNCS"
  echo
  echo "## NOT captured anywhere (re-enter by hand)"
  echo "- Edge Function secrets (Dashboard -> Edge Functions -> Secrets)"
  echo "- Auth provider / SMTP / OAuth configuration"
  echo "- API keys (anon, service_role) and JWT secret"
} > "$OUT_ABS/manifest-extras.txt"

cat "$OUT_ABS/manifest-extras.txt"

find "$OUT_ABS" -type f -print0 | xargs -0 shasum -a 256 > "$OUT_ABS/SHA256SUMS" 2>/dev/null || true

cd "$(dirname "$OUT_ABS")"
tar czf "$(basename "$OUT_ABS").tar.gz" "$(basename "$OUT_ABS")"

echo
echo "==> DONE"
echo "    archive: ${OUT_ABS}.tar.gz ($(du -h "${OUT_ABS}.tar.gz" | cut -f1))"
